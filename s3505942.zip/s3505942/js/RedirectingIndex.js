$(document).ready(function(){
			   setTimeout(function(){
               window.location="index.html";}
			   , 5000);
            });	
